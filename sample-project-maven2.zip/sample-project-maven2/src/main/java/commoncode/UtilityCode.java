package commoncode;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UtilityCode {

	public static void scrollToElement(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", element);
	
	}
	
	@SuppressWarnings("deprecation")
	public static void waitForElementToBeclickable(WebDriver driver,WebElement element) {
		WebDriverWait wait= new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	public static void waitForElementsToBeVisible(WebDriver driver,List<WebElement> list) {
		@SuppressWarnings("deprecation")
		WebDriverWait wait= new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOfAllElements(list));
	}
	
	public static void javaScriptExeClick(WebDriver driver,WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
	}
}
