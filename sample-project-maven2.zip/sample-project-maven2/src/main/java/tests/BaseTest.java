package tests;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BaseTest {

	static String driverType="Chrome";
	static WebDriver driver;
	
	
	public static WebDriver openBrowser() {
		
		System.out.println("open browser method called....");
		if(driverType.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
			driver= new ChromeDriver();
			System.out.println("Opening chrome browser :"+driver);
			driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
			
		}
		else if(driverType.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
			driver= new FirefoxDriver();
			System.out.println("Opening firefox browser :"+driver);
			driver.get("https://www.way2automation.com/angularjs-protractor/banking/#/login");
		}
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		return driver;
	}
	
	
	public static void closeBrowser() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.quit();
		System.out.println("Browser has been closed");
	}
}
