package tests;

import static org.junit.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import commoncode.UtilityCode;
import pages.AddCustomerPage;
import pages.CustomersPage;
import pages.LoginPage;
import pages.OpenAccountPage;

public class XyzBankTest extends BaseTest{
	static WebDriver driver;
	
	@Test
	public void customerVerificationTest() {
		//this.driver=BaseTest.driver;
		 this.driver=BaseTest.openBrowser();
		 System.out.println(this.driver);
		LoginPage lp = new LoginPage(driver);
		lp.clickManagerLogin();
		
		AddCustomerPage acp = new AddCustomerPage(driver);
		acp.addCustomerDetails("Raju", "Duvvada");
		
		OpenAccountPage oap = new OpenAccountPage(driver);
		oap.openAccount("Raju Duvvada");
		
		CustomersPage cp = new CustomersPage(driver);
		cp.clickCustomersTab();
		cp.verifyCustomerCreation("Raju");
				
		BaseTest.closeBrowser();
		
	}
	

}
