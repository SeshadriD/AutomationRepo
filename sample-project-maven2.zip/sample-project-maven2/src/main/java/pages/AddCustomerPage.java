package pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commoncode.UtilityCode;

public class AddCustomerPage {

	static WebDriver driver;
	@FindBy(xpath="//button[contains(text(),'Add Customer')]")
	private WebElement addCustomerTab;
	
	@FindBy(xpath="//input[@placeholder=\"First Name\"]")
	private WebElement firstNameTextbox;
	
	@FindBy(xpath="//input[@placeholder=\"Last Name\"]")
	private WebElement lastNameTextbox;
	
	@FindBy(xpath="//input[@placeholder=\"Post Code\"]")
	private WebElement postCodeTextbox;
	
	@FindBy(xpath="//button[text()='Add Customer']")
	private WebElement addCustomerButton;
	
	@FindBy(xpath="//button[contains(text(),'Open Account')]")
	private WebElement openAccountTab;
	
	
	
	public AddCustomerPage(WebDriver driver) {
		this.driver=driver;
		//PageFactory.initElements(driver, AddCustomerPage.class);
		PageFactory.initElements(driver, this);
		
	}
	
	public void addCustomerDetails(String firstName,String lastName) {
		
		UtilityCode.waitForElementToBeclickable(driver, addCustomerTab);
		addCustomerTab.click();
		System.out.println("Clickedon Add cust button");
		UtilityCode.waitForElementToBeclickable(driver, firstNameTextbox);
		firstNameTextbox.sendKeys(firstName);
		lastNameTextbox.sendKeys(lastName);
		postCodeTextbox.sendKeys("543252");
		addCustomerButton.click();
		Alert a = driver.switchTo().alert();
		System.out.println(a.getText());
		a.accept();
		System.out.println("Popup accepted");
		
	}
}	
