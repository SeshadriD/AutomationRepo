package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commoncode.UtilityCode;

public class LoginPage {

	 static WebDriver driver;
	
	
	@FindBy(xpath="//button[text()='Bank Manager Login']")
	private WebElement bnkMngrLoginButton;
	
	public LoginPage(WebDriver driver) {
		System.out.println("Entered constructor");
		this.driver=driver;
		//PageFactory.initElements(driver, LoginPage.class);
		PageFactory.initElements(driver, this);
		System.out.println("Driver object in the constructor "+this.driver);
		System.out.println("Page objects are initialised..");
		
	}
	
	public void clickManagerLogin() {
		//UtilityCode.waitForElementToBeclickable(driver, bnkMngrLoginButton);
		bnkMngrLoginButton.click();
		System.out.println("Clicked on Bank manager login");
	}
}
