package pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import commoncode.UtilityCode;

public class OpenAccountPage {

	static WebDriver driver;
	
	@FindBy(xpath="//button[contains(text(),'Open Account')]")
	private WebElement openAccountTab;
	
	@FindBy(id="userSelect")
	private WebElement customerDropdown;
	
	@FindBy(xpath="//select[@id='currency']")
	private WebElement currencyDropdown;
	
	@FindBy(xpath="//button[text()='Process']")
	private WebElement processButton;
	
	public OpenAccountPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	
	public void openAccount(String customer) {
		UtilityCode.waitForElementToBeclickable(driver, openAccountTab);
		openAccountTab.click();
		UtilityCode.waitForElementToBeclickable(driver, customerDropdown);
		Select custDrop= new Select(customerDropdown);
		custDrop.selectByVisibleText(customer);
		
		Select currDrop= new Select(currencyDropdown);
		currDrop.selectByVisibleText("Rupee");
		processButton.click();
		
		Alert a= driver.switchTo().alert();
		System.out.println(a.getText());
		a.accept();
		System.out.println("Account created");
		
		
		
		
	}
}
