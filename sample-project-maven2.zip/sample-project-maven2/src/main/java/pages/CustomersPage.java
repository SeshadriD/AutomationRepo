package pages;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commoncode.UtilityCode;

public class CustomersPage {

	static  WebDriver driver;
	
	@FindBy(xpath="//button[contains(text(),'Customers')]")
	private WebElement customersTab;
	
	@FindBy(xpath="//input[@placeholder=\"Search Customer\"]")
	private WebElement custSearchbox;
	
	@FindBy(xpath="//table[@class=\"table table-bordered table-striped\"]/tbody/tr/td[1]")
	private List<WebElement> customerList;
	
	
	public CustomersPage(WebDriver driver) {
		
		this.driver=driver;
		
		PageFactory.initElements(driver, this);
	}
	
	public void clickCustomersTab() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("driver object is "+driver);
		UtilityCode.waitForElementToBeclickable(driver, customersTab);
		customersTab.click();
		System.out.println("Clicked on Customers tab");
	}
	
	public void verifyCustomerCreation(String customerFirstName) {
		UtilityCode.waitForElementToBeclickable(driver, custSearchbox);
		custSearchbox.sendKeys(customerFirstName);
		String actCust=customerList.get(0).getText();
		assertTrue(customerFirstName.equals(actCust));
		System.out.println("Customer has verifid successfully");
	}
}
